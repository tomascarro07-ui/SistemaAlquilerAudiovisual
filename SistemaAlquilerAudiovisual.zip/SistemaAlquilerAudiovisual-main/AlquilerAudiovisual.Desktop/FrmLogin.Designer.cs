﻿namespace AlquilerAudiovisual.Desktop
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TxtUser = new TextBox();
            TxtPassword = new TextBox();
            BtnLogin = new Button();
            BtnSalir = new Button();
            LinkLblRegistro = new LinkLabel();
            LblUser = new Label();
            LblPass = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // TxtUser
            // 
            TxtUser.Location = new Point(291, 366);
            TxtUser.Name = "TxtUser";
            TxtUser.PlaceholderText = "ejemplo@correo.com";
            TxtUser.Size = new Size(269, 27);
            TxtUser.TabIndex = 0;
            TxtUser.Tag = "";
            // 
            // TxtPassword
            // 
            TxtPassword.Location = new Point(291, 454);
            TxtPassword.Name = "TxtPassword";
            TxtPassword.PlaceholderText = "Contraseña";
            TxtPassword.Size = new Size(269, 27);
            TxtPassword.TabIndex = 1;
            // 
            // BtnLogin
            // 
            BtnLogin.BackColor = Color.SteelBlue;
            BtnLogin.Location = new Point(456, 542);
            BtnLogin.Name = "BtnLogin";
            BtnLogin.Size = new Size(104, 41);
            BtnLogin.TabIndex = 2;
            BtnLogin.Text = "Entrar";
            BtnLogin.UseVisualStyleBackColor = false;
            BtnLogin.Click += BtnLogin_Click;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.IndianRed;
            BtnSalir.Location = new Point(275, 542);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(104, 41);
            BtnSalir.TabIndex = 3;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // LinkLblRegistro
            // 
            LinkLblRegistro.AutoSize = true;
            LinkLblRegistro.Location = new Point(386, 598);
            LinkLblRegistro.Name = "LinkLblRegistro";
            LinkLblRegistro.Size = new Size(64, 20);
            LinkLblRegistro.TabIndex = 4;
            LinkLblRegistro.TabStop = true;
            LinkLblRegistro.Text = "Registro";
            LinkLblRegistro.LinkClicked += LinkLblRegistro_LinkClicked;
            // 
            // LblUser
            // 
            LblUser.AutoSize = true;
            LblUser.Font = new Font("Segoe UI", 10F);
            LblUser.Location = new Point(344, 340);
            LblUser.Name = "LblUser";
            LblUser.Size = new Size(151, 23);
            LblUser.TabIndex = 5;
            LblUser.Text = "Correo electrónico";
            // 
            // LblPass
            // 
            LblPass.AutoSize = true;
            LblPass.Font = new Font("Segoe UI", 10F);
            LblPass.Location = new Point(367, 428);
            LblPass.Name = "LblPass";
            LblPass.Size = new Size(97, 23);
            LblPass.TabIndex = 6;
            LblPass.Text = "Contraseña";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.AVPro_850x290;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(850, 290);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(874, 681);
            Controls.Add(pictureBox1);
            Controls.Add(LblPass);
            Controls.Add(LblUser);
            Controls.Add(LinkLblRegistro);
            Controls.Add(BtnSalir);
            Controls.Add(BtnLogin);
            Controls.Add(TxtPassword);
            Controls.Add(TxtUser);
            ForeColor = SystemColors.ControlText;
            Name = "FrmLogin";
            Text = "Login";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TxtUser;
        private TextBox TxtPassword;
        private Button BtnLogin;
        private Button BtnSalir;
        private LinkLabel LinkLblRegistro;
        private Label LblUser;
        private Label LblPass;
        private PictureBox pictureBox1;
    }
}