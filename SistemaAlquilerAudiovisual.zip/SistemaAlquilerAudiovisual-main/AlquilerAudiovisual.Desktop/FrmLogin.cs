﻿using AlquilerAudiovisual.Dominio;
using AlquilerAudiovisual.Entities.Clientes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AlquilerAudiovisual.Desktop
{
    public partial class FrmLogin : Form
    {
        private List<Cliente> _clientes;

        public FrmLogin()
        {
            InitializeComponent();
            _clientes = [];
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TxtUser.Text))
                MessageBox.Show("El Correo es obligatorio", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            if (string.IsNullOrEmpty(TxtPassword.Text))
                MessageBox.Show("La contraseña es obligatoria", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            try
            {
                GestorAutenticacion gestor = new GestorAutenticacion();
                var datoCuenta = gestor.Login(TxtUser.Text, TxtPassword.Text);
                FrmMain main = new FrmMain(datoCuenta);
                this.Hide();
                DialogResult result = main.ShowDialog();
                if (result == DialogResult.Cancel)
                {
                    LimpiarControles();
                    this.Show();
                }
                else if (result == DialogResult.Abort)
                    this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
            }
            
        }

        private void LinkLblRegistro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //FrmRegistro frmLogin = new FrmRegistro(MiCuenta.Id);
            //frmLogin.MdiParent = this;
            //frmLogin.Show();
        }

        private void LimpiarControles()
        {
            TxtUser.Text = string.Empty;
            TxtPassword.Text = string.Empty;
        }
    }
}
