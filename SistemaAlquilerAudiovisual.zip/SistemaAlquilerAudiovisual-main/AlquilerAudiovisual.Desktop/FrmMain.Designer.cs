﻿namespace AlquilerAudiovisual.Desktop
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            usuarioToolStripMenuItem = new ToolStripMenuItem();
            verUsuarioToolStripMenuItem = new ToolStripMenuItem();
            logOutToolStripMenuItem = new ToolStripMenuItem();
            salirToolStripMenuItem = new ToolStripMenuItem();
            equiposToolStripMenuItem = new ToolStripMenuItem();
            equiposIndividualesToolStripMenuItem = new ToolStripMenuItem();
            equiposPorCantidadToolStripMenuItem = new ToolStripMenuItem();
            agregarEquiposToolStripMenuItem = new ToolStripMenuItem();
            modificarEquiposToolStripMenuItem = new ToolStripMenuItem();
            eliminarEquiposToolStripMenuItem = new ToolStripMenuItem();
            depositoToolStripMenuItem = new ToolStripMenuItem();
            clientesToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripMenuItem();
            reportesToolStripMenuItem = new ToolStripMenuItem();
            generarReporteToolStripMenuItem = new ToolStripMenuItem();
            listadoDeReportesToolStripMenuItem = new ToolStripMenuItem();
            solicituesToolStripMenuItem = new ToolStripMenuItem();
            crearSolicitudToolStripMenuItem = new ToolStripMenuItem();
            verSolicitudesToolStripMenuItem = new ToolStripMenuItem();
            solicitudesFinalizadasToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { usuarioToolStripMenuItem, equiposToolStripMenuItem, depositoToolStripMenuItem, clientesToolStripMenuItem, reportesToolStripMenuItem, solicituesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1327, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // usuarioToolStripMenuItem
            // 
            usuarioToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { verUsuarioToolStripMenuItem, logOutToolStripMenuItem, salirToolStripMenuItem });
            usuarioToolStripMenuItem.Name = "usuarioToolStripMenuItem";
            usuarioToolStripMenuItem.Size = new Size(73, 24);
            usuarioToolStripMenuItem.Text = "&Usuario";
            // 
            // verUsuarioToolStripMenuItem
            // 
            verUsuarioToolStripMenuItem.Name = "verUsuarioToolStripMenuItem";
            verUsuarioToolStripMenuItem.Size = new Size(165, 26);
            verUsuarioToolStripMenuItem.Text = "&Ver usuario";
            // 
            // logOutToolStripMenuItem
            // 
            logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            logOutToolStripMenuItem.Size = new Size(165, 26);
            logOutToolStripMenuItem.Text = "&Log out";
            // 
            // salirToolStripMenuItem
            // 
            salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            salirToolStripMenuItem.Size = new Size(165, 26);
            salirToolStripMenuItem.Text = "&Salir";
            // 
            // equiposToolStripMenuItem
            // 
            equiposToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { equiposIndividualesToolStripMenuItem, equiposPorCantidadToolStripMenuItem, agregarEquiposToolStripMenuItem, modificarEquiposToolStripMenuItem, eliminarEquiposToolStripMenuItem });
            equiposToolStripMenuItem.Name = "equiposToolStripMenuItem";
            equiposToolStripMenuItem.Size = new Size(76, 24);
            equiposToolStripMenuItem.Text = "&Equipos";
            // 
            // equiposIndividualesToolStripMenuItem
            // 
            equiposIndividualesToolStripMenuItem.Name = "equiposIndividualesToolStripMenuItem";
            equiposIndividualesToolStripMenuItem.Size = new Size(236, 26);
            equiposIndividualesToolStripMenuItem.Text = "Equipos &Individuales";
            // 
            // equiposPorCantidadToolStripMenuItem
            // 
            equiposPorCantidadToolStripMenuItem.Name = "equiposPorCantidadToolStripMenuItem";
            equiposPorCantidadToolStripMenuItem.Size = new Size(236, 26);
            equiposPorCantidadToolStripMenuItem.Text = "Equipos por &Cantidad";
            // 
            // agregarEquiposToolStripMenuItem
            // 
            agregarEquiposToolStripMenuItem.Name = "agregarEquiposToolStripMenuItem";
            agregarEquiposToolStripMenuItem.Size = new Size(236, 26);
            agregarEquiposToolStripMenuItem.Text = "&Agregar Equipos";
            // 
            // modificarEquiposToolStripMenuItem
            // 
            modificarEquiposToolStripMenuItem.Name = "modificarEquiposToolStripMenuItem";
            modificarEquiposToolStripMenuItem.Size = new Size(236, 26);
            modificarEquiposToolStripMenuItem.Text = "&Modificar Equipos";
            // 
            // eliminarEquiposToolStripMenuItem
            // 
            eliminarEquiposToolStripMenuItem.Name = "eliminarEquiposToolStripMenuItem";
            eliminarEquiposToolStripMenuItem.Size = new Size(236, 26);
            eliminarEquiposToolStripMenuItem.Text = "&Eliminar Equipos";
            // 
            // depositoToolStripMenuItem
            // 
            depositoToolStripMenuItem.Name = "depositoToolStripMenuItem";
            depositoToolStripMenuItem.Size = new Size(84, 24);
            depositoToolStripMenuItem.Text = "&Deposito";
            // 
            // clientesToolStripMenuItem
            // 
            clientesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem1 });
            clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            clientesToolStripMenuItem.Size = new Size(75, 24);
            clientesToolStripMenuItem.Text = "&Clientes";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(224, 26);
            toolStripMenuItem1.Text = "&Listar Clientes";
            // 
            // reportesToolStripMenuItem
            // 
            reportesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { generarReporteToolStripMenuItem, listadoDeReportesToolStripMenuItem });
            reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            reportesToolStripMenuItem.Size = new Size(82, 24);
            reportesToolStripMenuItem.Text = "&Reportes";
            // 
            // generarReporteToolStripMenuItem
            // 
            generarReporteToolStripMenuItem.Name = "generarReporteToolStripMenuItem";
            generarReporteToolStripMenuItem.Size = new Size(224, 26);
            generarReporteToolStripMenuItem.Text = "&Generar Reporte";
            // 
            // listadoDeReportesToolStripMenuItem
            // 
            listadoDeReportesToolStripMenuItem.Name = "listadoDeReportesToolStripMenuItem";
            listadoDeReportesToolStripMenuItem.Size = new Size(224, 26);
            listadoDeReportesToolStripMenuItem.Text = "&Listado de Reportes";
            // 
            // solicituesToolStripMenuItem
            // 
            solicituesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { crearSolicitudToolStripMenuItem, verSolicitudesToolStripMenuItem, solicitudesFinalizadasToolStripMenuItem });
            solicituesToolStripMenuItem.Name = "solicituesToolStripMenuItem";
            solicituesToolStripMenuItem.Size = new Size(86, 24);
            solicituesToolStripMenuItem.Text = "&Solicitues";
            // 
            // crearSolicitudToolStripMenuItem
            // 
            crearSolicitudToolStripMenuItem.Name = "crearSolicitudToolStripMenuItem";
            crearSolicitudToolStripMenuItem.Size = new Size(241, 26);
            crearSolicitudToolStripMenuItem.Text = "&Crear solicitud";
            // 
            // verSolicitudesToolStripMenuItem
            // 
            verSolicitudesToolStripMenuItem.Name = "verSolicitudesToolStripMenuItem";
            verSolicitudesToolStripMenuItem.Size = new Size(241, 26);
            verSolicitudesToolStripMenuItem.Text = "&Ver Solicitudes";
            // 
            // solicitudesFinalizadasToolStripMenuItem
            // 
            solicitudesFinalizadasToolStripMenuItem.Name = "solicitudesFinalizadasToolStripMenuItem";
            solicitudesFinalizadasToolStripMenuItem.Size = new Size(241, 26);
            solicitudesFinalizadasToolStripMenuItem.Text = "&Solicitudes &Finalizadas";
            // 
            // FrmMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(1327, 912);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "FrmMain";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem usuarioToolStripMenuItem;
        private ToolStripMenuItem verUsuarioToolStripMenuItem;
        private ToolStripMenuItem logOutToolStripMenuItem;
        private ToolStripMenuItem salirToolStripMenuItem;
        private ToolStripMenuItem equiposToolStripMenuItem;
        private ToolStripMenuItem equiposIndividualesToolStripMenuItem;
        private ToolStripMenuItem equiposPorCantidadToolStripMenuItem;
        private ToolStripMenuItem agregarEquiposToolStripMenuItem;
        private ToolStripMenuItem modificarEquiposToolStripMenuItem;
        private ToolStripMenuItem eliminarEquiposToolStripMenuItem;
        private ToolStripMenuItem depositoToolStripMenuItem;
        private ToolStripMenuItem clientesToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem reportesToolStripMenuItem;
        private ToolStripMenuItem generarReporteToolStripMenuItem;
        private ToolStripMenuItem listadoDeReportesToolStripMenuItem;
        private ToolStripMenuItem solicituesToolStripMenuItem;
        private ToolStripMenuItem crearSolicitudToolStripMenuItem;
        private ToolStripMenuItem verSolicitudesToolStripMenuItem;
        private ToolStripMenuItem solicitudesFinalizadasToolStripMenuItem;
    }
}
