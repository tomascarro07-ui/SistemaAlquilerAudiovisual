namespace AlquilerAudiovisual.Desktop
{
    public partial class FrmMain : Form
    {
        public FrmMain(object datoCuenta)
        {
            InitializeComponent();
        }
    }
}
