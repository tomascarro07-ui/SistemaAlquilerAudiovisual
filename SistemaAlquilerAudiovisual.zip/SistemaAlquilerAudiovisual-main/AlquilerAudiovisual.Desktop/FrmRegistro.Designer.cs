﻿namespace AlquilerAudiovisual.Desktop
{
    partial class FrmRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblName = new Label();
            lblCorreo = new Label();
            lblTelefono = new Label();
            lblDireccion = new Label();
            TxtName = new TextBox();
            TxtMail = new TextBox();
            TxtDireccion = new TextBox();
            textBox4 = new TextBox();
            label5 = new Label();
            TxtPassword = new TextBox();
            lblPass = new Label();
            BtnRegistro = new Button();
            BtnCancelar = new Button();
            LinkLblCuentaExistente = new LinkLabel();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.ForeColor = SystemColors.ControlText;
            lblName.Location = new Point(317, 111);
            lblName.Name = "lblName";
            lblName.Size = new Size(64, 20);
            lblName.TabIndex = 0;
            lblName.Text = "Nombre";
            // 
            // lblCorreo
            // 
            lblCorreo.AutoSize = true;
            lblCorreo.Location = new Point(317, 206);
            lblCorreo.Name = "lblCorreo";
            lblCorreo.Size = new Size(132, 20);
            lblCorreo.TabIndex = 1;
            lblCorreo.Text = "Correo electrónico";
            // 
            // lblTelefono
            // 
            lblTelefono.AutoSize = true;
            lblTelefono.Location = new Point(317, 478);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(67, 20);
            lblTelefono.TabIndex = 2;
            lblTelefono.Text = "Telefono";
            // 
            // lblDireccion
            // 
            lblDireccion.AutoSize = true;
            lblDireccion.Location = new Point(317, 390);
            lblDireccion.Name = "lblDireccion";
            lblDireccion.Size = new Size(72, 20);
            lblDireccion.TabIndex = 3;
            lblDireccion.Text = "Dirección";
            // 
            // TxtName
            // 
            TxtName.Location = new Point(317, 134);
            TxtName.Name = "TxtName";
            TxtName.PlaceholderText = "Dario";
            TxtName.Size = new Size(238, 27);
            TxtName.TabIndex = 4;
            // 
            // TxtMail
            // 
            TxtMail.Location = new Point(317, 229);
            TxtMail.Name = "TxtMail";
            TxtMail.PlaceholderText = "ejemplo@correo.com";
            TxtMail.Size = new Size(238, 27);
            TxtMail.TabIndex = 5;
            // 
            // TxtDireccion
            // 
            TxtDireccion.Location = new Point(317, 413);
            TxtDireccion.Name = "TxtDireccion";
            TxtDireccion.PlaceholderText = "Rosenthal 460bis";
            TxtDireccion.Size = new Size(238, 27);
            TxtDireccion.TabIndex = 6;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(317, 501);
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = "098681725";
            textBox4.Size = new Size(238, 27);
            textBox4.TabIndex = 7;
            // 
            // label5
            // 
            label5.Font = new Font("Times New Roman", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(361, 26);
            label5.Name = "label5";
            label5.Size = new Size(150, 50);
            label5.TabIndex = 8;
            label5.Text = "Registro";
            // 
            // TxtPassword
            // 
            TxtPassword.Location = new Point(317, 322);
            TxtPassword.Name = "TxtPassword";
            TxtPassword.PlaceholderText = "********";
            TxtPassword.Size = new Size(238, 27);
            TxtPassword.TabIndex = 10;
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Location = new Point(317, 299);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(83, 20);
            lblPass.TabIndex = 9;
            lblPass.Text = "Contraseña";
            // 
            // BtnRegistro
            // 
            BtnRegistro.BackColor = Color.SteelBlue;
            BtnRegistro.Location = new Point(486, 563);
            BtnRegistro.Name = "BtnRegistro";
            BtnRegistro.Size = new Size(113, 42);
            BtnRegistro.TabIndex = 11;
            BtnRegistro.Text = "Registrarse";
            BtnRegistro.UseVisualStyleBackColor = false;
            BtnRegistro.Click += BtnRegistro_Click;
            // 
            // BtnCancelar
            // 
            BtnCancelar.BackColor = Color.IndianRed;
            BtnCancelar.Location = new Point(268, 563);
            BtnCancelar.Name = "BtnCancelar";
            BtnCancelar.Size = new Size(113, 42);
            BtnCancelar.TabIndex = 12;
            BtnCancelar.Text = "Cancelar";
            BtnCancelar.UseVisualStyleBackColor = false;
            BtnCancelar.Click += BtnCancelar_Click;
            // 
            // LinkLblCuentaExistente
            // 
            LinkLblCuentaExistente.AutoSize = true;
            LinkLblCuentaExistente.Location = new Point(379, 624);
            LinkLblCuentaExistente.Name = "LinkLblCuentaExistente";
            LinkLblCuentaExistente.Size = new Size(115, 20);
            LinkLblCuentaExistente.TabIndex = 13;
            LinkLblCuentaExistente.TabStop = true;
            LinkLblCuentaExistente.Text = "Ya tengo cuenta";
            LinkLblCuentaExistente.LinkClicked += LinkLblCuentaExistente_LinkClicked;
            // 
            // FrmRegistro
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(874, 681);
            Controls.Add(LinkLblCuentaExistente);
            Controls.Add(BtnCancelar);
            Controls.Add(BtnRegistro);
            Controls.Add(TxtPassword);
            Controls.Add(lblPass);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(TxtDireccion);
            Controls.Add(TxtMail);
            Controls.Add(TxtName);
            Controls.Add(lblDireccion);
            Controls.Add(lblTelefono);
            Controls.Add(lblCorreo);
            Controls.Add(lblName);
            ForeColor = SystemColors.ControlText;
            Name = "FrmRegistro";
            Text = "FrmRegistro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private Label lblCorreo;
        private Label lblTelefono;
        private Label lblDireccion;
        private TextBox TxtName;
        private TextBox TxtMail;
        private TextBox TxtDireccion;
        private TextBox textBox4;
        private Label label5;
        private TextBox TxtPassword;
        private Label lblPass;
        private Button BtnRegistro;
        private Button BtnCancelar;
        private LinkLabel LinkLblCuentaExistente;
    }
}