﻿using AlquilerAudiovisual.Dominio;
using AlquilerAudiovisual.Entities.Clientes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace AlquilerAudiovisual.Desktop
{
    public partial class FrmRegistro : Form
    {
        [ToolStripItemDesignerAvailability(DesignerSerializationVisibility.Hidden)]
        public Cliente NuevaCuenta { get; private set; }

        public FrmRegistro(Cliente cliente)
        {
            InitializeComponent();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void BtnRegistro_Click(object sender, EventArgs e)
        {
            GestorAutenticacion gestor = new GestorAutenticacion();
            try
            {
                NuevaCuenta = gestor.CrearCuenta(
                    TxtName.Text,
                    TxtPassword.Text,
                    TxtMail.Text,
                    TxtDireccion.Text);
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
            }
        }

        private void LinkLblCuentaExistente_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Vuelve al login.
        }
    }
}
