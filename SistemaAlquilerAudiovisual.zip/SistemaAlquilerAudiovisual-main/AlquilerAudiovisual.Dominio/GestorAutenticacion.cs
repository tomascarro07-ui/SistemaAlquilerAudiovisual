﻿using AlquilerAudiovisual.Entities.Clientes;
using AlquilerAudiovisual.Persistencia.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;


namespace AlquilerAudiovisual.Dominio
{
    public class GestorAutenticacion
    {
        IDalCliente? _dalCliente;
        private Cliente Owner;

        public GestorAutenticacion()
        {
            _dalCliente = new Persistencia.Interfaces.IDalCliente();
        }

        public Cliente Login(string correo, string password)
        {
            if (string.IsNullOrEmpty(correo))
                throw new Exception("El correo es obligatorio");
            if (string.IsNullOrEmpty(password))
                throw new Exception("La contraseña es obligatoria");
            var cliente = _dalCliente.BuscarClientePorOwner(correo);
            if (cliente == null)
                throw new Exception("El correo no está registrado");
            if (cliente.TipoCliente.Password != password)
                throw new Exception("La contraseña es incorrecta");
            return cliente;

            var nuevoCliente = _dalCliente?.BuscarClientePorOwner(correo);
            if (cliente is null)
                throw new InvalidOperationException("No se pudo encontrar su usuario. Por favor verifique los datos.");
            else
            {
                Owner = new Cliente()
                {
                    Nombre = cliente.Nombre,
                    Correo = cliente.Correo,
                    Direccion = cliente.Direccion,
                    Documento = cliente.Documento,
                    Telefono = cliente.Telefono
                };
                TipoCliente = TipoCliente.Personal
              };
            _dalCliente?.GuardarCliente(nuevoCliente);
            return nuevoCliente;
        }
    }
}
