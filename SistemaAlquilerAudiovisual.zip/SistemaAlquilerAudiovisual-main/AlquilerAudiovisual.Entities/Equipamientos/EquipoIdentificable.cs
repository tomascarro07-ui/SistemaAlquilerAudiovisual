﻿using AlquilerAudiovisual.Entities.Enumerados;

namespace AlquilerAudiovisual.Entities.Equipamientos
{
    public class EquipoIdentificable : Equipo
    {
        public required string NumeroSerie { get; set; }
        public required string CodigoInterno { get; set; }
        public void CambiarEstado(EstadoEquipo nuevo, string obs)
        {
            Estado = nuevo;
            Historial.Add(new CambioEstadoEquipo { NuevoEstado = nuevo, FechaCambio = DateOnly.FromDateTime(DateTime.Today), Observaciones = obs });
        }

        public override bool EstaDisponible(DateTime desde, DateTime hasta, int cantidad)
        {
            //Hacer luego
            throw new NotImplementedException();
        }
    }
}
