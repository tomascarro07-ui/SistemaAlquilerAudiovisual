﻿using AlquilerAudiovisual.Entities.Clientes;

namespace AlquilerAudiovisual.Persistencia.Interfaces
{
    public interface IDalCliente
    {
        Cliente? BuscarClientePorOwner(string ownerEmail);
        int AgregarCliente(Cliente cliente);
        void GuardarCliente(Cliente nuevoCliente);

        //void ActualizarCliente(Cliente cliente);
        //List<Cliente> ListarClientes();
        //Cliente? ObtenerClientePorId(int idCliente);
        //Cliente? ObtenerPorDocumento(string documento);
        //List<TipoCliente> ListarTipos();
    }
}
